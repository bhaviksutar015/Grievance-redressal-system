import { Mail, MapPin, GraduationCap, MessageSquareText } from "lucide-react";
import { Link } from "react-router-dom";

export default function Contact() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl">
          Contact
        </h1>
        <p className="mt-3 text-slate-500">
          Questions about this CEP project or the platform? Reach out.
        </p>
      </header>

      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        <div className="card p-6">
          <GraduationCap className="h-6 w-6 text-civic-600" aria-hidden="true" />
          <h2 className="mt-3 font-semibold text-slate-900 dark:text-white">Project</h2>
          <p className="mt-1 text-sm text-slate-500">
            OGRSA — Online Grievance Redressal System Awareness.
            <br /> BSc IT Community Engagement Project (CEP).
          </p>
        </div>
        <div className="card p-6">
          <Mail className="h-6 w-6 text-civic-600" aria-hidden="true" />
          <h2 className="mt-3 font-semibold text-slate-900 dark:text-white">Email</h2>
          <p className="mt-1 text-sm text-slate-500">
            Use your institution-provided project contact address.
          </p>
        </div>
        <div className="card p-6">
          <MapPin className="h-6 w-6 text-civic-600" aria-hidden="true" />
          <h2 className="mt-3 font-semibold text-slate-900 dark:text-white">Location</h2>
          <p className="mt-1 text-sm text-slate-500">Mumbai, Maharashtra, India.</p>
        </div>
        <div className="card p-6">
          <MessageSquareText className="h-6 w-6 text-civic-600" aria-hidden="true" />
          <h2 className="mt-3 font-semibold text-slate-900 dark:text-white">
            Have a grievance instead?
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Don't email it — <Link to="/submit" className="font-medium text-civic-600 hover:underline">submit it through the platform</Link>{" "}
            so it gets a reference ID and a trackable timeline.
          </p>
        </div>
      </div>

      <p className="mt-8 rounded-lg bg-amber-50 p-4 text-center text-sm text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
        Educational disclaimer: OGRSA is a student project. For real grievances,
        please use the official portals of your local municipal corporation or
        the relevant government department.
      </p>
    </div>
  );
}
