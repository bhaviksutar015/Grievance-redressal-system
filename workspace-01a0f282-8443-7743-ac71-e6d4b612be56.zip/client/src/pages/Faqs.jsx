import { useEffect, useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";
import { api } from "../lib/api";
import { EmptyState, Spinner } from "../components/ui";

export default function Faqs() {
  const [faqs, setFaqs] = useState(null);
  const [open, setOpen] = useState(null);

  useEffect(() => {
    api
      .get("/awareness")
      .then(({ data }) => setFaqs(data.data.filter((r) => r.section === "FAQ")))
      .catch(() => setFaqs([]));
  }, []);

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl">
          Frequently Asked Questions
        </h1>
        <p className="mt-3 text-slate-500">
          Quick answers about using this grievance redressal platform.
        </p>
      </header>

      <div className="mt-8 space-y-3">
        {faqs === null && <Spinner />}
        {faqs?.length === 0 && (
          <EmptyState icon={HelpCircle} title="No FAQs yet" hint="Please check back soon." />
        )}
        {faqs?.map((f) => (
          <div key={f.id} className="card overflow-hidden">
            <button
              className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-medium text-slate-800 dark:text-slate-100"
              onClick={() => setOpen(open === f.id ? null : f.id)}
              aria-expanded={open === f.id}
            >
              {f.title}
              <ChevronDown
                className={`h-5 w-5 shrink-0 text-slate-400 transition-transform ${open === f.id ? "rotate-180" : ""}`}
                aria-hidden="true"
              />
            </button>
            {open === f.id && (
              <p className="border-t border-slate-100 px-5 py-4 text-sm leading-relaxed text-slate-600 dark:border-slate-800 dark:text-slate-400">
                {f.body}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
