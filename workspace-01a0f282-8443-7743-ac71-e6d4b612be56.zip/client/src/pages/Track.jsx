import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, Ticket } from "lucide-react";
import { api } from "../lib/api";
import { StatusBadge, ErrorAlert, Spinner } from "../components/ui";
import Timeline from "../components/Timeline";
import { formatDate } from "../lib/constants";

export default function Track() {
  const [params] = useSearchParams();
  const [ref, setRef] = useState(params.get("ref") ?? "");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const search = async (e) => {
    e?.preventDefault();
    const value = ref.trim().toUpperCase();
    if (!value) {
      setError("Please enter your reference ID.");
      return;
    }
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const { data } = await api.get(`/grievances/track/${encodeURIComponent(value)}`);
      setResult(data.data);
    } catch (err) {
      setError(err.friendlyMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl">
          Track Your Grievance
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-slate-500">
          Enter the reference ID you received after submission (e.g.{" "}
          <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs dark:bg-slate-800">
            OGRSA-2026-000001
          </code>
          ). No login required — and no personal details are ever shown here.
        </p>
      </header>

      <form onSubmit={search} className="card mt-8 flex flex-col gap-3 p-5 sm:flex-row">
        <label htmlFor="ref" className="sr-only">
          Reference ID
        </label>
        <input
          id="ref"
          className="input flex-1 font-mono uppercase"
          placeholder="OGRSA-2026-000001"
          value={ref}
          onChange={(e) => setRef(e.target.value)}
          autoComplete="off"
        />
        <button className="btn-primary" disabled={loading}>
          <Search className="h-4 w-4" aria-hidden="true" />
          {loading ? "Searching…" : "Track"}
        </button>
      </form>

      <div className="mt-6">
        <ErrorAlert message={error} />
        {loading && <Spinner label="Looking up your grievance…" />}

        {result && (
          <div className="card p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="flex items-center gap-2 font-mono text-sm text-civic-600 dark:text-civic-400">
                  <Ticket className="h-4 w-4" aria-hidden="true" />
                  {result.referenceId}
                </p>
                <h2 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                  {result.subject}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Category: {result.category} · Submitted {formatDate(result.createdAt)} ·
                  Last updated {formatDate(result.updatedAt)}
                </p>
              </div>
              <StatusBadge status={result.status} />
            </div>

            <h3 className="mt-6 mb-4 text-sm font-semibold uppercase tracking-wide text-slate-500">
              Progress Timeline
            </h3>
            <Timeline entries={result.timeline} showRemarks={false} />

            <p className="mt-6 rounded-lg bg-slate-50 p-3 text-xs text-slate-500 dark:bg-slate-800/60">
              For privacy, public tracking shows only the status timeline. Sign in
              as the grievance owner to see full details, official remarks and
              attachments.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
