import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  FileText,
  Megaphone,
  SearchCheck,
  ShieldCheck,
  Users,
  ClipboardList,
  CheckCircle2,
  Timer,
  ArrowRight,
  Landmark,
  BellRing,
  BookOpenCheck,
} from "lucide-react";
import { api } from "../lib/api";

const HIGHLIGHTS = [
  {
    icon: FileText,
    title: "What is a grievance?",
    text: "A formal complaint about a public service problem — broken roads, water supply, sanitation, and more.",
  },
  {
    icon: Megaphone,
    title: "Why online systems matter",
    text: "No queues, no paperwork lost in files. Digital submissions are recorded, time-stamped and trackable.",
  },
  {
    icon: ClipboardList,
    title: "How to submit",
    text: "Register, describe your issue, attach evidence and get a unique reference ID instantly.",
  },
  {
    icon: SearchCheck,
    title: "How to track",
    text: "Use your reference ID any time — no login needed — to see exactly where your grievance stands.",
  },
  {
    icon: ShieldCheck,
    title: "Rights & responsibilities",
    text: "You have the right to be heard and the responsibility to report honestly with accurate details.",
  },
];

export default function Home() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api
      .get("/stats/public")
      .then(({ data }) => setStats(data.data))
      .catch(() => {});
  }, []);

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-to-br from-civic-700 via-civic-600 to-civic-800 text-white">
        <div className="pointer-events-none absolute inset-0 opacity-10" aria-hidden="true">
          <Landmark className="absolute -right-10 -top-10 h-72 w-72 rotate-12" />
          <FileText className="absolute bottom-10 left-8 h-40 w-40 -rotate-12" />
        </div>
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:py-24 lg:grid-cols-2">
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide">
              <BookOpenCheck className="h-3.5 w-3.5" aria-hidden="true" />
              Educational CEP Project
            </p>
            <h1 className="text-3xl font-extrabold leading-tight sm:text-5xl">
              Your Voice Matters. Raise Your Grievance. Track Its Resolution.
            </h1>
            <p className="mt-5 max-w-xl text-civic-100 sm:text-lg">
              OGRSA teaches citizens how online grievance redressal works — and
              lets you experience it hands-on. Submit a grievance, receive a
              reference ID, follow a transparent status timeline and give
              feedback after resolution.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/submit" className="btn bg-white px-5 py-3 text-civic-700 hover:bg-civic-50">
                Submit a Grievance <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <Link
                to="/awareness"
                className="btn border border-white/40 px-5 py-3 text-white hover:bg-white/10"
              >
                Learn About Grievance Redressal
              </Link>
            </div>
          </div>

          {/* Icon-based illustration */}
          <div className="hidden justify-center lg:flex" aria-hidden="true">
            <div className="grid w-full max-w-md gap-4">
              {[
                { icon: FileText, t: "1 · Submit", d: "Describe your civic issue with evidence" },
                { icon: BellRing, t: "2 · Get notified", d: "Status updates at every single step" },
                { icon: Timer, t: "3 · Track progress", d: "Transparent timeline, reference ID" },
                { icon: CheckCircle2, t: "4 · Resolution", d: "Closure with your feedback & rating" },
              ].map(({ icon: Icon, t, d }, i) => (
                <div
                  key={t}
                  className="flex items-center gap-4 rounded-2xl bg-white/10 p-4 backdrop-blur"
                  style={{ marginLeft: `${i * 20}px` }}
                >
                  <span className="rounded-xl bg-white/20 p-3">
                    <Icon className="h-6 w-6" />
                  </span>
                  <div>
                    <p className="font-semibold">{t}</p>
                    <p className="text-sm text-civic-100">{d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* LIVE STATS */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="card grid grid-cols-2 divide-slate-200 dark:divide-slate-800 sm:grid-cols-4 sm:divide-x">
          {[
            { label: "Grievances Registered", value: stats?.registered, icon: FileText },
            { label: "Grievances Resolved", value: stats?.resolved, icon: CheckCircle2 },
            { label: "In Progress", value: stats?.inProgress, icon: Timer },
            { label: "Citizens Reached", value: stats?.citizens, icon: Users },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="flex flex-col items-center gap-1 p-6 text-center">
              <Icon className="h-6 w-6 text-civic-600" aria-hidden="true" />
              <p className="text-3xl font-extrabold text-slate-900 dark:text-white">
                {value ?? "—"}
              </p>
              <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                {label}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-2 text-center text-xs text-slate-400">
          Live figures generated by this educational application — not government
          statistics.
        </p>
      </section>

      {/* AWARENESS HIGHLIGHTS */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <h2 className="text-center text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">
          Awareness Highlights
        </h2>
        <p className="mx-auto mt-2 max-w-2xl text-center text-slate-500">
          The heart of this CEP project: understanding your rights and the
          grievance redressal process.
        </p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {HIGHLIGHTS.map(({ icon: Icon, title, text }) => (
            <article key={title} className="card p-6 transition-shadow hover:shadow-md">
              <span className="inline-flex rounded-xl bg-civic-100 p-3 text-civic-700 dark:bg-civic-950 dark:text-civic-300">
                <Icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <h3 className="mt-4 font-semibold text-slate-900 dark:text-white">{title}</h3>
              <p className="mt-2 text-sm text-slate-500">{text}</p>
            </article>
          ))}
          <article className="card flex flex-col items-start justify-center gap-3 bg-civic-600 p-6 text-white dark:bg-civic-700">
            <h3 className="text-lg font-bold">Ready to learn more?</h3>
            <p className="text-sm text-civic-100">
              Visit the full Awareness Hub with guides, tips, common mistakes and
              FAQs.
            </p>
            <Link to="/awareness" className="btn bg-white px-4 py-2 text-civic-700 hover:bg-civic-50">
              Open Awareness Hub <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </article>
        </div>
      </section>

      {/* HOW IT WORKS PREVIEW */}
      <section className="bg-white py-14 dark:bg-slate-900">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-center text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">
            How It Works
          </h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Register / Login", "Create a free account secured by Neon Auth."],
              ["Submit Grievance", "Category, description, location & evidence."],
              ["Track with Reference ID", "Watch it move through each stage."],
              ["Resolution & Feedback", "Rate the resolution once complete."],
            ].map(([t, d], i) => (
              <div key={t} className="relative rounded-xl border border-slate-200 p-6 dark:border-slate-800">
                <span className="absolute -top-4 left-6 flex h-8 w-8 items-center justify-center rounded-full bg-civic-600 text-sm font-bold text-white">
                  {i + 1}
                </span>
                <h3 className="mt-2 font-semibold text-slate-900 dark:text-white">{t}</h3>
                <p className="mt-1 text-sm text-slate-500">{d}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link to="/how-it-works" className="btn-secondary">
              See the full 7-step workflow <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-14">
        <div className="card flex flex-col items-center gap-4 bg-gradient-to-r from-civic-600 to-civic-800 p-10 text-center text-white">
          <h2 className="text-2xl font-bold sm:text-3xl">
            Have a civic issue? Don't stay silent.
          </h2>
          <p className="max-w-xl text-civic-100">
            Every grievance you raise makes public services more accountable.
            Try the complete workflow on this educational platform.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/register" className="btn bg-white px-5 py-3 text-civic-700 hover:bg-civic-50">
              Create Free Account
            </Link>
            <Link to="/track" className="btn border border-white/40 px-5 py-3 text-white hover:bg-white/10">
              Track a Grievance
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
