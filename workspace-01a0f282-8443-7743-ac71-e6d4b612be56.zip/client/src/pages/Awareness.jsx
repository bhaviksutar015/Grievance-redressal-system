import { useEffect, useState } from "react";
import {
  FileText,
  Globe,
  ThumbsUp,
  ClipboardList,
  Info,
  SearchCheck,
  Workflow,
  UserCheck,
  AlertTriangle,
  ChevronDown,
  Lightbulb,
} from "lucide-react";
import { api } from "../lib/api";

const SECTIONS = [
  {
    icon: FileText,
    title: "A. What is a grievance?",
    body: "A grievance is a formal complaint raised by a citizen about a deficiency in a public service — for example a broken street light, irregular water supply, uncollected garbage, potholes, or delays in getting certificates. It is different from a suggestion or an enquiry: a grievance points to something specific that has gone wrong and needs corrective action.",
  },
  {
    icon: Globe,
    title: "B. What is an online grievance redressal system?",
    body: "It is a web platform where citizens can lodge complaints digitally instead of visiting offices. Each complaint gets a unique reference number, is routed to the responsible department, and its progress is recorded step by step until closure. Real-world examples in India include CPGRAMS (national level) and various state/municipal portals. OGRSA is an educational model of such a system.",
  },
  {
    icon: ThumbsUp,
    title: "C. Why should citizens use online grievance systems?",
    body: "Convenience: file from home, 24×7. Proof: every submission is time-stamped with a reference ID. Transparency: you can see the status at any time. Accountability: officials' actions are recorded in a permanent history. Speed: digital routing removes paperwork delays. Inclusivity: elderly and differently-abled citizens can participate without travelling.",
  },
  {
    icon: ClipboardList,
    title: "D. How to file a grievance",
    body: "1) Register with your email and sign in. 2) Click 'Submit Grievance'. 3) Choose the correct category (e.g. Water Supply). 4) Write a clear subject and a detailed description — what, where, since when. 5) Add the location and department if known. 6) Attach a photo or document as evidence. 7) Submit and save the reference ID shown on the confirmation screen.",
  },
  {
    icon: Info,
    title: "E. What information should be provided?",
    body: "Provide facts: exact location (ward, street, landmark), date and duration of the problem, how it affects residents, and any earlier complaint attempts. Attach supporting evidence (photo, bill, receipt — PDF/JPG/PNG). Give a working mobile number so officials can reach you. Avoid abusive language, speculation and unrelated issues.",
  },
  {
    icon: SearchCheck,
    title: "F. How to track a grievance",
    body: "Use the 'Track Grievance' page and enter your reference ID (format OGRSA-YYYY-NNNNNN). You will see the current status and the complete timeline of transitions. Tracking is public but privacy-safe: it never reveals personal details, only the subject, category, status and dates. Signed-in citizens see full details, remarks and attachments in their dashboard.",
  },
  {
    icon: Workflow,
    title: "G. What happens after submission?",
    body: "Your grievance follows a defined workflow: SUBMITTED → UNDER REVIEW (an officer verifies details) → ASSIGNED (routed to the responsible department) → IN PROGRESS (action being taken) → RESOLVED (with closing remarks) — or REJECTED with a recorded reason if it is invalid or outside scope. You receive an in-app notification at every step, and every change is stored permanently in the status history.",
  },
  {
    icon: UserCheck,
    title: "H. Citizen responsibilities",
    body: "Report truthfully — false complaints waste public resources. One grievance per issue. Choose the correct category. Respond if officials ask for additional information. Track your grievance and give honest feedback after resolution. Never misuse the system for personal disputes, spam or defamation.",
  },
  {
    icon: AlertTriangle,
    title: "I. Common mistakes when submitting grievances",
    body: "Vague descriptions ('road is bad' — where exactly?). Wrong category, which delays routing. Missing location details. No evidence attached when it was easily available. Multiple unrelated problems in one complaint. Submitting duplicates instead of tracking the original. Ignoring requests for additional information. Losing the reference ID.",
  },
];

export default function Awareness() {
  const [dynamic, setDynamic] = useState({ tips: [], faqs: [] });
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    api
      .get("/awareness")
      .then(({ data }) => {
        const rows = data.data;
        setDynamic({
          tips: rows.filter((r) => r.section === "TIP"),
          faqs: rows.filter((r) => r.section === "FAQ"),
        });
      })
      .catch(() => {});
  }, []);

  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl">
          Awareness Hub
        </h1>
        <p className="mx-auto mt-3 max-w-2xl text-slate-500">
          The educational core of this CEP project — everything an ordinary
          citizen should know about online grievance redressal, in simple
          language.
        </p>
      </header>

      {/* A–I sections */}
      <div className="mt-10 grid gap-5 md:grid-cols-2">
        {SECTIONS.map(({ icon: Icon, title, body }) => (
          <article key={title} className="card p-6">
            <div className="flex items-center gap-3">
              <span className="rounded-xl bg-civic-100 p-2.5 text-civic-700 dark:bg-civic-950 dark:text-civic-300">
                <Icon className="h-5 w-5" aria-hidden="true" />
              </span>
              <h2 className="font-semibold text-slate-900 dark:text-white">{title}</h2>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              {body}
            </p>
          </article>
        ))}
      </div>

      {/* Dynamic tips from the database */}
      {dynamic.tips.length > 0 && (
        <section className="mt-14">
          <h2 className="flex items-center gap-2 text-2xl font-bold text-slate-900 dark:text-white">
            <Lightbulb className="h-6 w-6 text-amber-500" aria-hidden="true" />
            Quick Tips
          </h2>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            {dynamic.tips.map((t) => (
              <div
                key={t.id}
                className="rounded-xl border-l-4 border-amber-400 bg-amber-50 p-4 dark:bg-amber-950/30"
              >
                <p className="font-semibold text-slate-800 dark:text-slate-100">{t.title}</p>
                <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{t.body}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* J. FAQs (expandable, from database) */}
      <section className="mt-14" id="faqs">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
          J. Frequently Asked Questions
        </h2>
        <div className="mt-5 space-y-3">
          {dynamic.faqs.map((f) => (
            <div key={f.id} className="card overflow-hidden">
              <button
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-medium text-slate-800 dark:text-slate-100"
                onClick={() => setOpenFaq(openFaq === f.id ? null : f.id)}
                aria-expanded={openFaq === f.id}
              >
                {f.title}
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-slate-400 transition-transform ${openFaq === f.id ? "rotate-180" : ""}`}
                  aria-hidden="true"
                />
              </button>
              {openFaq === f.id && (
                <p className="border-t border-slate-100 px-5 py-4 text-sm leading-relaxed text-slate-600 dark:border-slate-800 dark:text-slate-400">
                  {f.body}
                </p>
              )}
            </div>
          ))}
          {dynamic.faqs.length === 0 && (
            <p className="text-sm text-slate-500">FAQs are being prepared.</p>
          )}
        </div>
      </section>
    </div>
  );
}
