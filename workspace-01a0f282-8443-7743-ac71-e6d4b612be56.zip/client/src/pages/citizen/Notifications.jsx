import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BellOff, CheckCheck } from "lucide-react";
import { api } from "../../lib/api";
import { EmptyState, ErrorAlert, TableSkeleton } from "../../components/ui";
import { formatDate } from "../../lib/constants";

export default function Notifications() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    setError("");
    try {
      const { data: res } = await api.get("/notifications");
      setData(res.data);
    } catch (err) {
      setError(err.friendlyMessage);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const markRead = async (id) => {
    try {
      await api.put(`/notifications/${id}/read`);
      setData((d) => ({
        unread: Math.max(0, d.unread - 1),
        items: d.items.map((n) => (n.id === id ? { ...n, isRead: true } : n)),
      }));
    } catch {
      /* ignore */
    }
  };

  const markAll = async () => {
    try {
      await api.put("/notifications/read-all");
      setData((d) => ({ unread: 0, items: d.items.map((n) => ({ ...n, isRead: true })) }));
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
          Notifications{" "}
          {data?.unread > 0 && (
            <span className="ml-1 rounded-full bg-rose-100 px-2 py-0.5 text-sm font-semibold text-rose-600 dark:bg-rose-950">
              {data.unread} new
            </span>
          )}
        </h1>
        {data?.unread > 0 && (
          <button onClick={markAll} className="btn-secondary text-sm">
            <CheckCheck className="h-4 w-4" aria-hidden="true" /> Mark all as read
          </button>
        )}
      </div>

      <ErrorAlert message={error} onRetry={load} />

      <div className="card">
        {data === null ? (
          <TableSkeleton rows={5} />
        ) : data.items.length === 0 ? (
          <EmptyState
            icon={BellOff}
            title="No notifications."
            hint="Status updates about your grievances will appear here."
          />
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {data.items.map((n) => (
              <li
                key={n.id}
                className={`flex gap-3 px-5 py-4 ${!n.isRead ? "bg-civic-50/60 dark:bg-civic-950/30" : ""}`}
              >
                <span
                  className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${!n.isRead ? "bg-civic-500" : "bg-transparent"}`}
                  aria-hidden="true"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-slate-800 dark:text-slate-200">{n.title}</p>
                  <p className="mt-0.5 text-sm text-slate-500">{n.message}</p>
                  <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <time>{formatDate(n.createdAt, true)}</time>
                    {n.grievanceId && (
                      <Link
                        to={`/my-grievances/${n.grievanceId}`}
                        className="font-medium text-civic-600 hover:underline"
                        onClick={() => !n.isRead && markRead(n.id)}
                      >
                        View grievance
                      </Link>
                    )}
                    {!n.isRead && (
                      <button
                        onClick={() => markRead(n.id)}
                        className="font-medium text-slate-500 hover:underline"
                      >
                        Mark as read
                      </button>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
