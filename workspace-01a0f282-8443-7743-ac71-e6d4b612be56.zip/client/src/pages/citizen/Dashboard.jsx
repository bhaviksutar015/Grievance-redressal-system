import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  FileText,
  Inbox,
  SearchCheck,
  Timer,
  CheckCircle2,
  FilePlus2,
  ArrowRight,
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { api } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import {
  StatCard,
  StatusBadge,
  PriorityBadge,
  EmptyState,
  TableSkeleton,
  ErrorAlert,
} from "../../components/ui";
import { formatDate, STATUS_LABELS, CHART_COLORS } from "../../lib/constants";

export default function Dashboard() {
  const { profile } = useAuth();
  const [stats, setStats] = useState(null);
  const [recent, setRecent] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    setError("");
    try {
      const [s, r] = await Promise.all([
        api.get("/grievances/stats/me"),
        api.get("/grievances/my?limit=5"),
      ]);
      setStats(s.data.data);
      setRecent(r.data.data.items);
    } catch (err) {
      setError(err.friendlyMessage);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const by = stats?.byStatus ?? {};
  const chartData = Object.entries(by).map(([k, v]) => ({
    name: STATUS_LABELS[k],
    value: v,
  }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            My Dashboard
          </h1>
          <p className="text-sm text-slate-500">
            Namaste, {profile?.name}. Here's the status of your grievances.
          </p>
        </div>
        <Link to="/submit" className="btn-primary">
          <FilePlus2 className="h-4 w-4" aria-hidden="true" /> New Grievance
        </Link>
      </div>

      <ErrorAlert message={error} onRetry={load} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard icon={FileText} label="Total Grievances" value={stats?.total ?? "—"} />
        <StatCard icon={Inbox} label="Submitted" value={by.SUBMITTED ?? 0} tone="sky" />
        <StatCard
          icon={SearchCheck}
          label="Under Review"
          value={(by.UNDER_REVIEW ?? 0) + (by.ASSIGNED ?? 0)}
          tone="amber"
        />
        <StatCard icon={Timer} label="In Progress" value={by.IN_PROGRESS ?? 0} tone="violet" />
        <StatCard icon={CheckCircle2} label="Resolved" value={by.RESOLVED ?? 0} tone="emerald" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent grievances */}
        <section className="card lg:col-span-2" aria-labelledby="recent-h">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-800">
            <h2 id="recent-h" className="font-semibold text-slate-900 dark:text-white">
              Recent Grievances
            </h2>
            <Link
              to="/my-grievances"
              className="flex items-center gap-1 text-sm font-medium text-civic-600 hover:underline"
            >
              View all <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </div>
          {recent === null ? (
            <TableSkeleton />
          ) : recent.length === 0 ? (
            <EmptyState
              title="No grievances submitted yet."
              hint="When you submit a grievance it will appear here with its live status."
              action={
                <Link to="/submit" className="btn-primary mt-2">
                  Submit your first grievance
                </Link>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                    <th className="px-5 py-3">Reference</th>
                    <th className="px-5 py-3">Subject</th>
                    <th className="px-5 py-3">Category</th>
                    <th className="px-5 py-3">Date</th>
                    <th className="px-5 py-3">Status</th>
                    <th className="px-5 py-3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {recent.map((g) => (
                    <tr
                      key={g.id}
                      className="border-b border-slate-100 last:border-0 dark:border-slate-800/60"
                    >
                      <td className="px-5 py-3 font-mono text-xs">{g.referenceId}</td>
                      <td className="max-w-[220px] truncate px-5 py-3 font-medium text-slate-800 dark:text-slate-200">
                        {g.subject}
                      </td>
                      <td className="px-5 py-3 text-slate-500">{g.category}</td>
                      <td className="px-5 py-3 text-slate-500">{formatDate(g.createdAt)}</td>
                      <td className="px-5 py-3">
                        <StatusBadge status={g.status} />
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex gap-2">
                          <Link
                            to={`/my-grievances/${g.id}`}
                            className="font-medium text-civic-600 hover:underline"
                          >
                            View
                          </Link>
                          <Link
                            to={`/track?ref=${g.referenceId}`}
                            className="font-medium text-slate-500 hover:underline"
                          >
                            Track
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Status chart */}
        <section className="card p-5" aria-labelledby="chart-h">
          <h2 id="chart-h" className="font-semibold text-slate-900 dark:text-white">
            Status Overview
          </h2>
          {chartData.length === 0 ? (
            <EmptyState
              title="No data yet"
              hint="Your grievance status distribution will appear here."
            />
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={chartData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80}>
                    {chartData.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
