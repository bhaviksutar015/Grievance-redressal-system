import { Link } from "react-router-dom";
import {
  UserPlus,
  FilePlus2,
  Ticket,
  Search,
  Wrench,
  CheckCircle2,
  Star,
  ArrowRight,
} from "lucide-react";

const STEPS = [
  {
    icon: UserPlus,
    title: "Register / Login",
    text: "Create a free account with your email. Authentication is handled securely by Neon Auth — the platform never stores your password.",
  },
  {
    icon: FilePlus2,
    title: "Submit Grievance",
    text: "Fill in the category, subject, detailed description, location, department and priority. Attach photos or documents as evidence (PDF/JPG/PNG, up to 5 MB).",
  },
  {
    icon: Ticket,
    title: "Receive Reference ID",
    text: "Instantly get a unique reference number like OGRSA-2026-000001. Save it — it lets you (or anyone you share it with) track progress without logging in.",
  },
  {
    icon: Search,
    title: "Grievance Reviewed",
    text: "An administrator reviews your submission, verifies the details and moves it to 'Under Review'. You get a notification the moment this happens.",
  },
  {
    icon: Wrench,
    title: "Action Taken",
    text: "The grievance is assigned to the responsible department and marked 'In Progress'. Officials add remarks that you can read in your dashboard.",
  },
  {
    icon: CheckCircle2,
    title: "Resolution",
    text: "Once fixed, the grievance is marked 'Resolved' with closing remarks and a resolution timestamp. Invalid grievances are rejected with a recorded reason.",
  },
  {
    icon: Star,
    title: "Citizen Feedback",
    text: "Rate the resolution from 1 to 5 stars and leave a comment. Feedback keeps the process accountable and is visible to administrators.",
  },
];

export default function HowItWorks() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <header className="text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white sm:text-4xl">
          How It Works
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-slate-500">
          Seven transparent steps from raising your voice to closing the loop.
        </p>
      </header>

      <ol className="relative mt-12 space-y-8 border-l-2 border-civic-200 pl-8 dark:border-civic-900 sm:ml-6">
        {STEPS.map(({ icon: Icon, title, text }, i) => (
          <li key={title} className="relative">
            <span className="absolute -left-[49px] flex h-9 w-9 items-center justify-center rounded-full bg-civic-600 text-white ring-4 ring-white dark:ring-slate-950">
              <Icon className="h-4 w-4" aria-hidden="true" />
            </span>
            <div className="card p-5">
              <p className="text-xs font-bold uppercase tracking-wider text-civic-600 dark:text-civic-400">
                Step {i + 1}
              </p>
              <h2 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                {title}
              </h2>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                {text}
              </p>
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-12 flex flex-wrap justify-center gap-3">
        <Link to="/submit" className="btn-primary px-5 py-3">
          Start Now — Submit a Grievance <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
        <Link to="/track" className="btn-secondary px-5 py-3">
          Track an Existing Grievance
        </Link>
      </div>
    </div>
  );
}
