import { useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  Landmark,
  LayoutDashboard,
  FilePlus2,
  FolderOpen,
  Bell,
  UserRound,
  LogOut,
  Menu,
  X,
  ListChecks,
  Tags,
  Star,
  BookOpenText,
  Home,
} from "lucide-react";
import ThemeToggle from "../components/ThemeToggle";
import NotificationBell from "../components/NotificationBell";
import { useAuth } from "../context/AuthContext";

const CITIZEN_NAV = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard", end: true },
  { to: "/submit", icon: FilePlus2, label: "Submit Grievance" },
  { to: "/my-grievances", icon: FolderOpen, label: "My Grievances" },
  { to: "/notifications", icon: Bell, label: "Notifications" },
  { to: "/profile", icon: UserRound, label: "My Profile" },
];

const ADMIN_NAV = [
  { to: "/admin", icon: LayoutDashboard, label: "Admin Dashboard", end: true },
  { to: "/admin/grievances", icon: ListChecks, label: "Grievances" },
  { to: "/admin/categories", icon: Tags, label: "Categories" },
  { to: "/admin/feedback", icon: Star, label: "Feedback" },
  { to: "/admin/awareness", icon: BookOpenText, label: "Awareness Content" },
];

export default function DashboardLayout({ admin = false }) {
  const [open, setOpen] = useState(false);
  const { profile, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();

  const nav = admin ? ADMIN_NAV : CITIZEN_NAV;

  const handleSignOut = async () => {
    await signOut();
    navigate("/", { replace: true });
  };

  const linkCls = ({ isActive }) =>
    `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
      isActive
        ? "bg-civic-600 text-white"
        : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
    }`;

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 py-5">
        <span className="rounded-lg bg-civic-600 p-2 text-white">
          <Landmark className="h-5 w-5" aria-hidden="true" />
        </span>
        <div>
          <p className="text-sm font-bold text-slate-900 dark:text-white">OGRSA</p>
          <p className="text-[10px] text-slate-500">
            {admin ? "Admin Console" : "Citizen Portal"}
          </p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3" aria-label={admin ? "Admin" : "Citizen"}>
        {nav.map(({ to, icon: Icon, label, end }) => (
          <NavLink key={to} to={to} end={end} className={linkCls} onClick={() => setOpen(false)}>
            <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
            {label}
          </NavLink>
        ))}
        {admin && (
          <NavLink to="/dashboard" className={linkCls} onClick={() => setOpen(false)}>
            <UserRound className="h-4 w-4" aria-hidden="true" /> Citizen View
          </NavLink>
        )}
        {!admin && isAdmin && (
          <NavLink to="/admin" className={linkCls} onClick={() => setOpen(false)}>
            <ListChecks className="h-4 w-4" aria-hidden="true" /> Admin Console
          </NavLink>
        )}
      </nav>

      <div className="border-t border-slate-200 p-3 dark:border-slate-800">
        <Link
          to="/"
          className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <Home className="h-4 w-4" aria-hidden="true" /> Public Site
        </Link>
        <button
          onClick={handleSignOut}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/40"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" /> Sign out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 lg:block">
        {sidebar}
      </aside>

      {/* Mobile sidebar */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true">
          <div
            className="absolute inset-0 bg-slate-900/50"
            onClick={() => setOpen(false)}
            aria-hidden="true"
          />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl dark:bg-slate-900">
            <button
              className="absolute right-3 top-4 rounded-lg p-2 text-slate-500"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
            {sidebar}
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between gap-3 border-b border-slate-200 bg-white/90 px-4 backdrop-blur dark:border-slate-800 dark:bg-slate-950/90">
          <button
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <p className="hidden text-sm text-slate-500 sm:block">
            {admin ? "Grievance administration" : "Welcome back"},{" "}
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              {profile?.name}
            </span>
          </p>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <ThemeToggle />
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
