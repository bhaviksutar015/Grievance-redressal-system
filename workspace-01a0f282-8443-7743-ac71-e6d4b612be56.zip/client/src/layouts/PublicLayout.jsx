import { useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { Landmark, Menu, X, LogIn, UserPlus, LayoutDashboard } from "lucide-react";
import ThemeToggle from "../components/ThemeToggle";
import { useAuth } from "../context/AuthContext";

const NAV = [
  { to: "/", label: "Home", end: true },
  { to: "/about", label: "About" },
  { to: "/awareness", label: "Awareness" },
  { to: "/how-it-works", label: "How It Works" },
  { to: "/track", label: "Track Grievance" },
  { to: "/faqs", label: "FAQs" },
  { to: "/contact", label: "Contact" },
];

export default function PublicLayout() {
  const [open, setOpen] = useState(false);
  const { user, isAdmin } = useAuth();

  const linkCls = ({ isActive }) =>
    `rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
      isActive
        ? "bg-civic-50 text-civic-700 dark:bg-civic-950 dark:text-civic-300"
        : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
    }`;

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-950/90">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4">
          <Link to="/" className="flex items-center gap-2" aria-label="OGRSA home">
            <span className="rounded-lg bg-civic-600 p-2 text-white">
              <Landmark className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="hidden sm:block">
              <span className="block text-base font-bold leading-tight text-slate-900 dark:text-white">
                OGRSA
              </span>
              <span className="block text-[10px] leading-tight text-slate-500">
                Grievance Redressal Awareness · CEP
              </span>
            </span>
          </Link>

          <nav className="hidden items-center gap-0.5 lg:flex" aria-label="Main">
            {NAV.map((n) => (
              <NavLink key={n.to} to={n.to} end={n.end} className={linkCls}>
                {n.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            {user ? (
              <Link to={isAdmin ? "/admin" : "/dashboard"} className="btn-primary px-3 py-2">
                <LayoutDashboard className="h-4 w-4" aria-hidden="true" />
                <span className="hidden sm:inline">Dashboard</span>
              </Link>
            ) : (
              <>
                <Link to="/login" className="btn-secondary hidden px-3 py-2 sm:inline-flex">
                  <LogIn className="h-4 w-4" aria-hidden="true" /> Login
                </Link>
                <Link to="/register" className="btn-primary px-3 py-2">
                  <UserPlus className="h-4 w-4" aria-hidden="true" />
                  <span className="hidden sm:inline">Register</span>
                </Link>
              </>
            )}
            <button
              className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
              onClick={() => setOpen(!open)}
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {open && (
          <nav
            className="border-t border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-950 lg:hidden"
            aria-label="Mobile"
          >
            <div className="flex flex-col gap-1">
              {NAV.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  end={n.end}
                  className={linkCls}
                  onClick={() => setOpen(false)}
                >
                  {n.label}
                </NavLink>
              ))}
              {!user && (
                <NavLink to="/login" className={linkCls} onClick={() => setOpen(false)}>
                  Login
                </NavLink>
              )}
            </div>
          </nav>
        )}
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-lg bg-civic-600 p-1.5 text-white">
                <Landmark className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="font-bold text-slate-900 dark:text-white">OGRSA</span>
            </div>
            <p className="mt-3 text-sm text-slate-500">
              Online Grievance Redressal System Awareness — an educational
              Community Engagement Project (CEP) demonstrating how digital
              grievance platforms empower citizens.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Explore</h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-500">
              <li><Link className="hover:text-civic-600" to="/awareness">Awareness Hub</Link></li>
              <li><Link className="hover:text-civic-600" to="/how-it-works">How It Works</Link></li>
              <li><Link className="hover:text-civic-600" to="/faqs">FAQs</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Citizens</h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-500">
              <li><Link className="hover:text-civic-600" to="/submit">Submit a Grievance</Link></li>
              <li><Link className="hover:text-civic-600" to="/track">Track a Grievance</Link></li>
              <li><Link className="hover:text-civic-600" to="/register">Create an Account</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Disclaimer</h3>
            <p className="mt-3 text-sm text-slate-500">
              This is a student CEP project for educational purposes. It is{" "}
              <strong>not</strong> an official government portal and is not
              integrated with any government system.
            </p>
          </div>
        </div>
        <div className="border-t border-slate-200 py-4 text-center text-xs text-slate-400 dark:border-slate-800">
          OGRSA · BSc IT Community Engagement Project · Built with React, Express &
          Neon PostgreSQL
        </div>
      </footer>
    </div>
  );
}
